from cgi import test
from ensurepip import version
from sklearn.metrics import mean_absolute_error
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder
import pandas as pd
import numpy as np
from .models import versions
from django.http import HttpResponse
from django.conf import settings

import os


def predict(form):

    motorcycles = pd.read_csv(os.path.join(settings.BASE_DIR,
                                           'management/static/original.csv'))
    motorcycles = motorcycles[['id', 'model',
                               'version', 'year', 'km', 'sell_price', 'brand']]
    motorcycles = motorcycles.dropna(axis=0)

    motorcycles['B-m'] = motorcycles['brand']+'->'+motorcycles['model']
    motorcycles['B-m.v'] = motorcycles['brand']+'->' + \
        motorcycles['model']+':'+motorcycles['version']
    motorcycles['B-m.v/y'] = motorcycles['brand']+'->'+motorcycles['model'] + \
        ':'+motorcycles['version']+'/'+str(motorcycles['year'])

    motorcycles['brand'] = motorcycles['brand'].str.lower()
    r = motorcycles.groupby(['brand']).size().reset_index().sort_values(
        by=0, ascending=False, ignore_index=True).reset_index()
    motorcycles = motorcycles.merge(r, on='brand', how='left')
    motorcycles = motorcycles[['id', 'brand', 'model', 'version',
                               'year', 'km', 'sell_price', 'B-m', 'B-m.v', 'B-m.v/y', 'index']]
    cardinality_cols = [
        cname for cname in motorcycles.columns if motorcycles[cname].dtype == "object"]
    numerical_cols = [
        cname for cname in motorcycles.columns if motorcycles[cname].dtype in ['int64', 'float64']]


################################################
    var_BM = 0
    foundB = False
    iB = -1
    foundM = False
    iM = -1
    i = 0
    while i in range(0, len(motorcycles['brand'])-1) and not (foundB and foundM):
        if motorcycles['brand'][i] == form['brand'].value().lower() and motorcycles['model'][i] == form['modelname'].value().lower():
            foundB = True
            foundM = True
            iB = iM = i
        elif motorcycles['brand'][i] == form['brand'].value().lower():
            foundB = True
            iB = i
        elif motorcycles['model'][i] == form['modelname'].value().lower():
            foundM = True
            iM = i
        i = i+1

    query_rank = motorcycles['index'][iB]

#####################################################

    motorcycles[cardinality_cols] = OrdinalEncoder(
    ).fit_transform(motorcycles[cardinality_cols])

    features = ['brand', 'model', 'version',
                'year', 'km', 'B-m', 'B-m.v', 'index']
    target = ['sell_price']

    X = motorcycles[features]
    y = motorcycles[target]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, train_size=0.75, test_size=0.25, random_state=1)

    i = 200
    j = 9
    k = 0.2

    modeltag = X['brand'][iB]
    versiontag = X['brand'][iB]
    if foundM:
        modeltag = X['model'][iM]
        versiontag = modeltag

    if(foundB and foundM):
        var_BM = X['B-m'][iB]
    else:
        var_BM = X['brand'][iB]+modeltag

    d = {
        'brand': [X['brand'][iB]],
        'model': [modeltag],
        'version': [versiontag],
        'year': float(form['year'].value()),
        'km': float(form['year'].value()),
        'B-m': var_BM,
        'B-m.v': var_BM,
        'index': query_rank,
    }

    d = pd.DataFrame(data=d)

    modelo = XGBRegressor(n_estimators=i, max_depth=j, learning_rate=k)
    modelo.fit(X_train, y_train)
    out = pd.DataFrame(modelo.predict(d))
    return str(float(out[0]))
