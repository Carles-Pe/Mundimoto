from django.urls import URLPattern, path

from . import views

urlpatterns = [
    path("reset/", views.csv_call, name="csv_call"),
    path("versions/", views.my_form_version, name="my_form_version"),
    path("brands/", views.my_form_brand, name="my_form_brand"),
    path("", views.main_manage, name="main_manage"),
]
