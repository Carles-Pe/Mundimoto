from django.shortcuts import render
from django.http import HttpResponse
from .forms import BrandForm, VersionForm
from .predictor import predict
from .models import versions
from django.conf import settings

import csv
import os


def csv_call(request):
    f = open(os.path.join(settings.BASE_DIR,
             'management/static/original.csv'), 'w')
    vars = versions.objects.select_related('brand')
    writer = csv.writer(f)
    writer.writerow(['id', 'model', 'version', 'year',
                    'km', 'sell_price', 'brand'])
    for var in vars:
        writer.writerow([var.id, var.modelname, var.version,
                        var.year, var.km, var.sell_price, var.brand])
    html = """
            <html><p>Predictor Updated :)</p>
            <form>
                <input type="button" value="Go back!" onclick="history.back()">
            </form>"""
    return HttpResponse(html)


def main_manage(request):
    return render(request, "select_in.html")


def my_form_brand(request):
    context = {"success": "none"}
    if request.method == "POST":
        form = BrandForm(request.POST)
        if form.is_valid():
            form.save()
    else:
        form = BrandForm()
    return render(request, "insertBrand.html", {"form": form})


def my_form_version(request):
    if request.method == "POST":
        form = VersionForm(request.POST)
        if request.POST['sell_price'] == '-1':
            html = """
            <html><p>The value is """+predict(form)+"""</p>
            <form>
                <input type="button" value="Go back!" onclick="history.back()">
            </form>"""
            return HttpResponse(html)
        elif form.is_valid():
            form.save()
    else:
        form = VersionForm()
    return render(request, "insertVersion.html", {"form": form})


def css(request):
    return render(request, "qfc-dark.css")
